import sqlite3

conn=sqlite3.connect('bloodbankdb.sqlite3')
mycursor=conn.cursor()
#mycursor.execute("Insert into blood_stock VALUES('1','B-','5')")
mycursor.execute("Select *from blood_stock ")

print(mycursor.fetchall())

conn.commit()

conn.close()

