from django.apps import AppConfig


class BloodConfig(AppConfig):
    name = 'blood'
